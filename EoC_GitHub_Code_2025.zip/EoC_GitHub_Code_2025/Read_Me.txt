Please read Me

The zip file contains the following contents.

1. Documents
2. hal_entry_c_source code

Documents:
The Documents folder contains the following technical items.

1. The RA2E1 Group: Evaluation Kit for RA2E1 Microcontroller Group - Quick Start Guide
2. Tutorial: Your First RA MCU Project - Blinky


hal_entry_c_source code:
This folder contains the hal_entry.c source code for the following EK-RA2E1 projects.

1. 2_Bit_Binary_Counter
2. 3_Bit_Binary_Counter
3. LED3_Blinky (hal code will allow LED 3 to flash at 1 Hz on the EK-RA2E1 kit only)


Questions or comments, please send to:

Dr. Don Wilcher
mrdon219@gmail.com
